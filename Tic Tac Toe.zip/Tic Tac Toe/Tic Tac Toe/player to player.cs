﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Tic_Tac_Toe.player_to_AI;


namespace Tic_Tac_Toe
{
    public partial class player_to_player : Form
    {
        int nr = 0;
        List<Button> buttons;
        Player currentPlayer;
        Player currentPlayer2;

        int XWincount = 0;
        int OWin = 0;

        public player_to_player()
        {
            InitializeComponent();
            Restartgame();
        }

        private void btn_click(object sender, EventArgs e)
        {
            nr++;
            Button b = (Button)sender;
            
            if (nr%2!=0 )
            {
                b.Text = "X";
                b.BackColor = Color.Cyan;
            }
            else
            {
                b.Text = "O";
                b.BackColor = Color.DarkSalmon;
            }
            b.Enabled = false;

            if((b1.Text == b2.Text && b2.Text == b3.Text && b1.Enabled == false) ||
               (b4.Text == b5.Text && b5.Text == b6.Text && b4.Enabled == false)||
               (b7.Text == b8.Text && b8.Text == b9.Text && b7.Enabled== false) ||
               (b1.Text == b4.Text && b4.Text == b7.Text && b1.Enabled == false)||
               (b2.Text == b5.Text && b5.Text == b8.Text && b2.Enabled ==false) ||
               (b3.Text == b6.Text && b6.Text == b9.Text && b3.Enabled == false)||
               (b1.Text == b5.Text && b5.Text == b9.Text && b1.Enabled ==false) ||
               (b3.Text == b5.Text && b5.Text == b7.Text && b3.Enabled == false) )

            {
                if (nr % 2 != 0)
                {
                    MessageBox.Show("X Wins");
                    XWincount++;
                    label1.Text = "X Win: " + XWincount;
                    Restartgame();
                }
                else
                {
                    MessageBox.Show("O Wins");
                    OWin++;
                    label2.Text = "O Win: " + OWin;
                    Restartgame();
                }
            }

        }


        private void Restartgame(object sender, EventArgs e)
        {
            Restartgame();
        }

        private void Restartgame()
        {
            buttons = new List<Button> { b1, b2, b3, b4, b5, b6, b7, b8, b9 };

            foreach (Button x in buttons)
            {
                x.Enabled = true;
                x.Text = "";
                x.BackColor = DefaultBackColor;
            }
            }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            new Form1().Show();
            Hide();
            

        }
    }
}
    
