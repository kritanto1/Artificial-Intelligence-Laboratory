﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Player_to_player
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
